# About Me Page

This is my old portfolio.  
I no longer need it because I made a new one: [https://www.vensin.dev/](https://www.vensin.dev/)

Feel free to use this code — it's really crap, haha 😄

I would love some credits if you do!
